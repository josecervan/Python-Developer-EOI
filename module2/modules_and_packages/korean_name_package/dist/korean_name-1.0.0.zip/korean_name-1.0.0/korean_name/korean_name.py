import korean_name.korean_name_code as code


def get_birth_date():
    day, month, year = input('Your birth date (dd/mm/yyyy):').split('/')
    return day, month, year


def get_korean_name(day, month, year):
    last_name = code.last_name[int(year[-1])]
    middle_name = code.middle_name[int(month)]
    first_name = code.first_name[int(day)]
    return last_name, middle_name, first_name
