from setuptools import setup

setup(
	name='korean_name',
	version='1.0.0',
	description='Your nam in korean',
	author='Jose Antonio Cerván García',
	url='https://github.com/josecervan',
	packages=['korean_name']
)