from setuptools import setup

setup(
	name="paquete",
	version="0.1",
	description="Paquete de ejemplo",
	author="Dumbledore",
	url="http://howguarts.magic",
	packages=["paquete","paquete.day_quote","paquete.month_quote"]
	)