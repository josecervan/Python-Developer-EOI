def show_quote():
	print("Cualquier tecnología suficientemente avanzada es indistinguible de la magia - Arthur C. Clarke")

class Proverb():
	def __init__(self):
		print("Agua que no has de beber, déjala correr")