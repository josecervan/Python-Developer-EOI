def show_dquote():
	print("En medio de la dificultad reside la oportunidad - Albert Einstein")

class Dproverb():
	def __init__(self):
		print("A quien madruga, Dios le ayuda")