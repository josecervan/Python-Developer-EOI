def show_mquote():
	print("Si das pescado a un hombre hambriento lo nutres durante una jornada"
		"\nSi le enseñas a pescar, le nutrirás toda su vida - lao Tsé")

class Mproverb():
	def __init__(self):
		print("Cada maestrillo tiene su librillo")